create function date_eq_timestamptz(date, timestamp with time zone) returns boolean
  language internal
as
$$
date_eq_timestamptz
$$;

comment on function date_eq_timestamptz(date, timestamptz) is 'implementation of = operator';

