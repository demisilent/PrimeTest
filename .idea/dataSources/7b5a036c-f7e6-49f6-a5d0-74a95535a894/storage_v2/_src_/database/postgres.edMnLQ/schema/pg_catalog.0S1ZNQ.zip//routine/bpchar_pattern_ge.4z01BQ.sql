create function bpchar_pattern_ge(character, character) returns boolean
  language internal
as
$$
bpchar_pattern_ge
$$;

comment on function bpchar_pattern_ge(bpchar, bpchar) is 'implementation of ~>=~ operator';

