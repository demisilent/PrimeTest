create function array_position(anyarray, anyelement) returns integer
  language internal
as
$$
array_position
$$;

comment on function array_position(anyarray, anyelement, int4) is 'returns an offset of value in array with start index';

