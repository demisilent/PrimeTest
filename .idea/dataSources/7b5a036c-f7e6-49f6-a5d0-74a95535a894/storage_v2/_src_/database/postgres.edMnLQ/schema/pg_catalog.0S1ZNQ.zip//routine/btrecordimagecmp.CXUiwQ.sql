create function btrecordimagecmp(record, record) returns integer
  language internal
as
$$
btrecordimagecmp
$$;

comment on function btrecordimagecmp(record, record) is 'less-equal-greater based on byte images';

