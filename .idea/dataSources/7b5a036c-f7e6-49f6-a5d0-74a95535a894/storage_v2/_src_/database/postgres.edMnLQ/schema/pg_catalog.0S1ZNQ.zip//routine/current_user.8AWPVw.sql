create function "current_user"() returns name
  language internal
as
$$
current_user
$$;

comment on function "current_user"() is 'current user name';

