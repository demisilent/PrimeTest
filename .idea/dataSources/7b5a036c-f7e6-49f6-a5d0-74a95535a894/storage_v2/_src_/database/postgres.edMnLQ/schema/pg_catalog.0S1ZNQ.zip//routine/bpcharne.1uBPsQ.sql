create function bpcharne(character, character) returns boolean
  language internal
as
$$
bpcharne
$$;

comment on function bpcharne(bpchar, bpchar) is 'implementation of <> operator';

