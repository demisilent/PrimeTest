create function cume_dist() returns double precision
  language internal
as
$$
window_cume_dist
$$;

comment on function cume_dist() is 'fractional row number within partition';

