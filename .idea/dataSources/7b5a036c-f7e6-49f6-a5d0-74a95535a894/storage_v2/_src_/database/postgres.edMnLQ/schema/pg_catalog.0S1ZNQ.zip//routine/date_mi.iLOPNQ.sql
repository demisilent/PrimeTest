create function date_mi(date, date) returns integer
  language internal
as
$$
date_mi
$$;

comment on function date_mi(date, date) is 'implementation of - operator';

