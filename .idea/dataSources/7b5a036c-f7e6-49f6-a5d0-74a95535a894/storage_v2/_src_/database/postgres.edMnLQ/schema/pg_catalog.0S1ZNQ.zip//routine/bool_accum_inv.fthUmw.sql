create function bool_accum_inv(internal, boolean) returns internal
  language internal
as
$$
bool_accum_inv
$$;

comment on function bool_accum_inv(internal, bool) is 'aggregate transition function';

