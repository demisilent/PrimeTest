create function database_to_xmlschema(nulls boolean, tableforest boolean, targetns text) returns xml
  language internal
as
$$
database_to_xmlschema
$$;

comment on function database_to_xmlschema(bool, bool, text) is 'map database structure to XML Schema';

