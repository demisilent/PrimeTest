create function bit(integer, integer) returns bit
  language internal
as
$$
bitfromint4
$$;

comment on function bit(bit, int4, bool) is 'adjust bit() to typmod length';

