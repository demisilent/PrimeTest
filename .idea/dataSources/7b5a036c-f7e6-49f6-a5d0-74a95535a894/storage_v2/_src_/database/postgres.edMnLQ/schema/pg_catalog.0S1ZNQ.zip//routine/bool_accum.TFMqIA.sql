create function bool_accum(internal, boolean) returns internal
  language internal
as
$$
bool_accum
$$;

comment on function bool_accum(internal, bool) is 'aggregate transition function';

