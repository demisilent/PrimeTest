create function byteanlike(bytea, bytea) returns boolean
  language internal
as
$$
byteanlike
$$;

comment on function byteanlike(bytea, bytea) is 'implementation of !~~ operator';

