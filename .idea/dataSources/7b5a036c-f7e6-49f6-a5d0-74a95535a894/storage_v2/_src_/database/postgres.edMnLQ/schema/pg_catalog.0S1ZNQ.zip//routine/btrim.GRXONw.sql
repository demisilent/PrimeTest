create function btrim(text, text) returns text
  language internal
as
$$
btrim
$$;

comment on function btrim(bytea, bytea) is 'trim both ends of string';

