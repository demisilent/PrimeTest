create function anyarray_recv(internal) returns anyarray
  language internal
as
$$
anyarray_recv
$$;

comment on function anyarray_recv(internal) is 'I/O';

