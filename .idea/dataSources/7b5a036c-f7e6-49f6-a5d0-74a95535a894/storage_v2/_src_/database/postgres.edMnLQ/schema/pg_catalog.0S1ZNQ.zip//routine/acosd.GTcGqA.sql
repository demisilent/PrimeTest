create function acosd(double precision) returns double precision
  language internal
as
$$
dacosd
$$;

comment on function acosd(float8) is 'arccosine, degrees';

