create function byteale(bytea, bytea) returns boolean
  language internal
as
$$
byteale
$$;

comment on function byteale(bytea, bytea) is 'implementation of <= operator';

