create function date_mii(date, integer) returns date
  language internal
as
$$
date_mii
$$;

comment on function date_mii(date, int4) is 'implementation of - operator';

