create function array_lower(anyarray, integer) returns integer
  language internal
as
$$
array_lower
$$;

comment on function array_lower(anyarray, int4) is 'array lower dimension';

