create function "RI_FKey_setdefault_del"() returns trigger
  language internal
as
$$
RI_FKey_setdefault_del
$$;

comment on function "RI_FKey_setdefault_del"() is 'referential integrity ON DELETE SET DEFAULT';

