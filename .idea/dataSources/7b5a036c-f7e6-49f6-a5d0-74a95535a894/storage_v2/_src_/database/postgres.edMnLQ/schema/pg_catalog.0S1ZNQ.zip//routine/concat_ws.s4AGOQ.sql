create function concat_ws(text, VARIADIC "any") returns text
  language internal
as
$$
text_concat_ws
$$;

comment on function concat_ws(text, any) is 'concatenate values with separators';

