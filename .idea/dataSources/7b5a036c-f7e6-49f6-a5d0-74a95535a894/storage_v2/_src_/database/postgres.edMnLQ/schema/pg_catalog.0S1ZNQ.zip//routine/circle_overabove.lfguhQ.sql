create function circle_overabove(circle, circle) returns boolean
  language internal
as
$$
circle_overabove
$$;

comment on function circle_overabove(circle, circle) is 'implementation of |&> operator';

