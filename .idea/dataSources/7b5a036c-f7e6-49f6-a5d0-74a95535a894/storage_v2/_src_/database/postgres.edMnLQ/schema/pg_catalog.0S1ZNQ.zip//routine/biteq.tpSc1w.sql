create function biteq(bit, bit) returns boolean
  language internal
as
$$
biteq
$$;

comment on function biteq(bit, bit) is 'implementation of = operator';

