create function array_remove(anyarray, anyelement) returns anyarray
  language internal
as
$$
array_remove
$$;

comment on function array_remove(anyarray, anyelement) is 'remove any occurrences of an element from an array';

