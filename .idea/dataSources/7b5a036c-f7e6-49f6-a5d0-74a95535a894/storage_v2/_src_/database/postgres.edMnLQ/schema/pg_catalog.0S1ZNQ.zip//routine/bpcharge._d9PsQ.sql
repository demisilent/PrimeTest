create function bpcharge(character, character) returns boolean
  language internal
as
$$
bpcharge
$$;

comment on function bpcharge(bpchar, bpchar) is 'implementation of >= operator';

