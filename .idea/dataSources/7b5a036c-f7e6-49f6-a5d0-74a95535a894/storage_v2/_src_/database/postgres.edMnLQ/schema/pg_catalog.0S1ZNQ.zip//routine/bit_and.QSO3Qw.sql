create function bit_and(smallint) returns smallint
  language internal
as
$$
aggregate_dummy
$$;

comment on function bit_and(bit) is 'bitwise-and bit aggregate';

