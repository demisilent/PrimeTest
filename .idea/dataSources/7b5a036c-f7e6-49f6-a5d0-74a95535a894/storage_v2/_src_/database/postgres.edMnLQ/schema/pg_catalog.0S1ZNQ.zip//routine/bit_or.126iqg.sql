create function bit_or(smallint) returns smallint
  language internal
as
$$
aggregate_dummy
$$;

comment on function bit_or(int2) is 'bitwise-or smallint aggregate';

