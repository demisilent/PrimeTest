create function cidr(inet) returns cidr
  language internal
as
$$
inet_to_cidr
$$;

comment on function cidr(inet) is 'convert inet to cidr';

