create function currtid(oid, tid) returns tid
  language internal
as
$$
currtid_byreloid
$$;

comment on function currtid(oid, tid) is 'latest tid of a tuple';

