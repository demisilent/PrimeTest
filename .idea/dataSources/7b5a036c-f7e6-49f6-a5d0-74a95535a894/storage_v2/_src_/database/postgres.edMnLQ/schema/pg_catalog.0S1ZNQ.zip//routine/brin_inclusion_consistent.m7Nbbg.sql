create function brin_inclusion_consistent(internal, internal, internal) returns boolean
  language internal
as
$$
brin_inclusion_consistent
$$;

comment on function brin_inclusion_consistent(internal, internal, internal) is 'BRIN inclusion support';

