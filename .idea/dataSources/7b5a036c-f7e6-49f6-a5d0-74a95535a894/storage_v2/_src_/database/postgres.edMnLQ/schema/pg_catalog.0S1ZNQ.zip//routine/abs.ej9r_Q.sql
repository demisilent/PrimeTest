create function abs(real) returns real
  language internal
as
$$
float4abs
$$;

comment on function abs(int8) is 'absolute value';

